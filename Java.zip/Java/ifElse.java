public class ifElse {
    public static void main(String[] args) {
        int a = 19;
        if (a > 18) {
            System.out.println("you can drive");
        }
        else{
            System.out.println("You can not drive");
        }
    }

}
