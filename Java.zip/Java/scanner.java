import java.util.Scanner;

public class scanner {
    public static void main(String[] args) {
        Scanner sc  = new Scanner(System.in);
        // System.out.println("Enter the value 1");
        // int a = sc.nextInt();
        // System.out.println("Entered value is : " + a);

        // System.out.println("Enter the value 2");
        // float b = sc.nextFloat();
        // System.out.println("Entered value is : " + b);

        // System.out.println("Enter the value of b1 : ");
        // boolean b1 = sc.hasNextInt();
        // System.out.println(b1);
        System.out.println("Enter a string :");
        String str = sc.nextLine();
        System.out.println(str);
    }
}
