
public class incrementDecrement {
    public static void main(String[] args) {
        byte x = 5;
        int y = 6;
        short z = 8;
        int b =y+z;
        System.out.println(b);
        float c = 6.75f + x;
        System.out.println(c);

        int i = 56;
        System.out.println(i++);
        System.out.println(i);
        System.out.println(++i);

        int a = 7;
        System.out.println(++a * 8);
        char ch = 'a';
        System.out.println(++ch);
        System.out.println(++ch);
    }
}
