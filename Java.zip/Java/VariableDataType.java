public class VariableDataType {
    public static void main(String args[]){
        byte a = 5;
        int  b = 10;
        long l = 3784789487287428L;
        float f = 5.8F;
        double d = 9.89;
        System.out.println(a);
        System.out.println(b);
        System.out.println(l);
        System.out.println(f);
        System.out.println(d);
    }
}
