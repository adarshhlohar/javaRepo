// package com.company;

public class hello{
    public static void main(String[] args){
        System.out.println("Hello World");
        System.out.println("Kya bolti java ki public");
    } 
}