public class tcsProblem {
    public static void main(String[] args) {
        
    }
}
