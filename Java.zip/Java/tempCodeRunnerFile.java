ride
    // public void record4kVideo(){
    //     System.out.println("recording in 4k and click to snap");
    // }