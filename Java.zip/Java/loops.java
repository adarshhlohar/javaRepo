public class loops {
    public static void main(String[] args) {
        System.out.println("Using loops");
        int i = 100;
        while (i<=200) {
            System.out.println(i);
            i++;
        }
        System.out.println("Finish running while loop");
    }
}
