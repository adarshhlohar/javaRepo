import java.util.Scanner;

class Subject {
    String SubName;
    int marks;

    public Subject(String SubName) {
        this.SubName = SubName;
        this.marks = 0;
    }
}

class Student {
    String name;
    int roll_no;

    // Creating array object of Subject class
    Subject[] subjects;

    public Student(String name, int roll_no) {
        this.name = name;
        this.roll_no = roll_no;

        // After calling the constructor of Student --> The Subject object can be
        // Created and thats constructor is also invoked.
        this.subjects = new Subject[] { new Subject("Math"), new Subject("English") };
    }
}

class Teacher {
    public void setMarks(Student students, int subjectIndex, int marks) {
        if (subjectIndex >= 0 && subjectIndex < students.subjects.length) {
            students.subjects[subjectIndex].marks = marks;
        }
    }
}

public class Assignment3 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        // Creating a Student object Array that can store 10 student object
        Student[] students = new Student[10];

        for (int i = 0; i < 10; i++) {
            int temp = i + 1;
            // storing the data of that students we are using for loop for and calling
            // constructor
            students[i] = new Student("student" + (temp), 1000 + temp);
        }

        // creating object of Teacher class
        Teacher teacher = new Teacher();

        // Setting the marks of each student
        for (Student student : students) {
            System.out.println(
                    "---Enter the mark of student :" + student.name + " ***Whose roll no is :" + student.roll_no);
            for (int i = 0; i < student.subjects.length; i++) {
                System.out.println("The mark of the subject is : " + student.subjects[i].SubName);
                int mark = sc.nextInt();

                // Setting the marks using the teacher object
                teacher.setMarks(student, i, mark);
            }
        }

        System.out.println("\nTeacher's Options:");
        System.out.println("Enter a Find average of marks");
        System.out.println("Enter b Find Max and Min and display the marks");

        char option = sc.next().charAt(0);

        if (option == 'a') {
            int totalMarks = 0;
            int totalSubjects = 0;
            for (Student std : students) {
                for (Subject subject : std.subjects) {
                    totalMarks += subject.marks;
                    totalSubjects++;
                }
            }
            System.out.println("the total subject is : " + totalSubjects);
            double average = (double) totalMarks / totalSubjects;
            System.out.println("Average marks: " + average);
        } 
        else if (option == 'b') {
            for (Student std : students) {
                for (Subject sub : std.subjects) {
                    System.out.println(std.name + "'s " + sub.SubName + " marks: " + sub.marks);
                }
            }

            int max = Integer.MIN_VALUE;
            int min = Integer.MAX_VALUE;

            for (Student std : students) {
                for (Subject sub : std.subjects) {
                    if (sub.marks > max) {
                        max= sub.marks;
                    }else if(sub.marks < min){
                        min = sub.marks;
                    }
                }
            }

            System.out.println("the max marks of the student is : " + max);
            System.out.println("the min marks of the student is : " + min);
        }
        else{
            System.out.println("Invalid option.....");
        }
        sc.close();
    }
}
