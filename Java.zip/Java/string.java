public class string {
    public static void main(String[] args) {
        // char[] str = {'A','D','A','R','S','H'}; 
        // its same as 
        String name ="Adarsh";
        // String str = new String("ADARSH");
        System.out.println("The name is : ");
        System.out.println(name);

        int a = 6;
        float b = 5.67f;
        System.out.printf("The value of a is %d and  b is %8.2f\n",a,b);
        System.out.format("The value of a is %d and  b is %8.2f",a,b);
    }
}
