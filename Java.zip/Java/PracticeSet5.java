public class PracticeSet5 {
    public static void main(String[] args) {
        // problem 1
        /*
         * int n = 4;
         * for (int i = n; i > 0; i--) {
         * for (int j = 0; j < i ; j++) {
         * System.out.print("*");
         * }
         * System.out.println();
         * }
         */

        // Problem 2
        /*
         * int sum = 0;
         * int n = 4;
         * 
         * for (int i = 0; i < n; i++) {
         * sum += 2*i;
         * }
         * System.out.println("The sum of first Even Numbers is : "+ sum);
         */

        // Problem 3 sum of even number using the While loop
        /*
         * int i =0;
         * int sum =0;
         * int n = 5;
         * 
         * while (i < n) {
         * sum += 2*i;
         * i++;
         * }
         * System.out.println("The sum of first Even Numbers is : "+ sum);
         */

        // Problem 4
        // int n =5;
        // for (int i = 1; i <= 10; i++) {
        // System.out.printf("%d X %d = %d\n", n,i,n*i);
        // }

        // Problem 5 in reverse of problem 4
        // int n = 5;
        // for (int i = 10; i > 0; i--) {
        // System.out.printf("%d X %d = %d\n", n,i,n*i);
        // }

        // Problem 6
        // int n = 5;
        // int i = 1;
        // int factorial = 1;
        // while (i <= n) {
        // factorial *= i;
        // i++;
        // }
        // System.out.println("The value of the factorial is : "+factorial);

        // problem 7
        /*
         * int n = 8;
         * int sum = 0;
         * for (int i = 1; i <= 10; i++) {
         * sum += n*i;
         * }
         * System.out.println("The total sum of the multiplication table  8 is : " +
         * sum);
         */
    }
}
