package Practice;

import java.util.Scanner;

public class palindrome {


    public static void checkPalindrome(int n){
        int originalNum = n;
        int reverse = 0;
        int reminder  = 0;
        int temp = 1;

        while (n != 0) {
            reminder = n%10;
            reverse += reminder * temp;
            temp *= 10;
            n /= 10;
            System.out.println("The reverse number is : " + reverse);
        }

        if(originalNum == reverse){
            System.out.println("This is palindrome");
        }
        else{
            System.out.println("This is not Pallindrome");
        }

        
    }
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int num;
        System.out.println("Enter The Number You want to check palindrome or not...");
        num = sc.nextInt();

        checkPalindrome(num);


        sc.close();
    }
}
