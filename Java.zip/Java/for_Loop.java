public class for_Loop {
    public static void main(String[] args) {
        // using increament
        // for(int i = 0;i<100; i++){
        //     System.out.println(i);
        // }
        // using the decreament
        for(int i = 10; i > 0; i--){
            System.out.println(i);
        }
    }
}
