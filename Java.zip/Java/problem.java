
import java.util.*;
public class problem {
    public static void main(String args[]){
        Scanner sc=new Scanner(System.in);
        int a=sc.nextInt();
        int sum=0;
        int remainder=0;
        while(a!=0){
            remainder =a%
        }

    }
    
}
