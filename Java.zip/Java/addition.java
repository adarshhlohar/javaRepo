import java.util.Scanner;
public class addition {
    public static void main(String[] args) {
        int a =4;
        int b = 6;
        int c = 8;
        int sum =  a+b+c;
        System.out.println(sum);

        // ex 2
        
        float subject1 = 45;
        float subject2 = 65;
        float subject3 = 65;
        float cgpa = (subject1+subject2+subject3)/30;
        System.out.println("The cgpa of three subject is " + cgpa);

        // ex 3
        System.out.println("Enter youre name");
        Scanner sc = new Scanner(System.in);
        String name = sc.next();
        System.out.println("Hello "+ name +" How are you");
    }
}
