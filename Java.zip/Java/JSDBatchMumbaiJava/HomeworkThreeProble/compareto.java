import java.lang.String;

public class compareto{
    public static void main(String[] args) {
        String str = "";
        String str2 = "";

        System.out.println(str.compareTo(str2) > 0);

    }
}