import java.lang.String;

public class exercise2 {

	public static void main(String[] args) {
		
		String s = "Welcome to Java World";
		
		System.out.println(s.charAt(5));
		
		System.out.println(s.compareTo("Welcome"));
		
		System.out.println(s.concat("- Let us learn"));
		
		System.out.println(s.indexOf('a'));
		
		System.out.println(s.substring(4,10));
		
		System.out.println(s.toLowerCase());
	}

}



