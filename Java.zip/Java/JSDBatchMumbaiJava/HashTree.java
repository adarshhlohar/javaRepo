import java.util.Iterator;

public class HashTree<T> {

    public void add(int i) {
    }

    public Iterator<Integer> iterator() {
        return null;
    }

}
