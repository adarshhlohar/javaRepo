public class exceptionHandlerImp {
    
    public static void main(String[] args) {
        int a = 1;
        int b = 0;
  
        // Try block to check for exceptions
        try {
            int i = computeDivision(a, b);
        }
  
        // Catch block to handle ArithmeticException
        // exceptions
        catch (ArithmeticException ex) {
  
            // getMessage() will print description
            // of exception(here / by zero)
            System.out.println(ex.getMessage());
        }
    }
}
