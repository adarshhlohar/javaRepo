public class empDetail {
    
    int empid;



    public static void main(String[] args) {
        empDetail em = new empDetail("mamta",9356986567,"adarshhlohar@gmail.com",);

    }
}
