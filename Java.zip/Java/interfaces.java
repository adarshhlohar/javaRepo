interface Bicycle {
    int a = 45; // by default final

    void applyBrake(int decreament);

    void speedUp(int increament);
}

interface blowHorn {
    void blowHornKGF();

    void blowHornPushpa();

}

class AvonBicycle implements Bicycle, blowHorn {
    public void applyBrake(int decreament) {
        System.out.println("Applying brake the speed is rduce by : " + decreament);
    }

    public void speedUp(int increament) {
        System.out.println("We can sppedUp the cycle speed by : " + increament);
    }

    public void blowHornKGF() {
        System.out.println("Blowing horn in KGF style ");
    }

    public void blowHornPushpa() {
        System.out.println("Blowing horn in Pushpa style ");
    }

}

public class interfaces {
    public static void main(String[] args) {
        AvonBicycle cycle = new AvonBicycle();
        cycle.applyBrake(1);
        cycle.speedUp(12);
        System.out.println(cycle.a);

        // the property of interfaces are final can be changed
        // cycle.a =233;
        // System.out.println(cycle.a);

        cycle.blowHornKGF();
        cycle.blowHornPushpa();
    }
}
